package aplicacion;

import javafx.stage.Stage;
//--------------------------
public class Escenario {
	
	//--------------------------
	public static Stage stage;
	//--------------------------
	public Escenario(Stage unStage){
		Escenario.stage = unStage;
	}
	//--------------------------
}
