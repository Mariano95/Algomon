package excepciones;

public class PokemonPropioSeDebilitoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PokemonPropioSeDebilitoException(){}
}

