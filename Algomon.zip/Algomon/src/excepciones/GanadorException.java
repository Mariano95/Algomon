package excepciones;

public class GanadorException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GanadorException(){};

}
