package excepciones;

public class PerdedorException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PerdedorException(){}
}

