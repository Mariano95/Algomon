package excepciones;

public class PokemonSeDebilitoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PokemonSeDebilitoException(){}
}
