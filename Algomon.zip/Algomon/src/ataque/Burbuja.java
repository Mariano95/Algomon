package ataque;

public class Burbuja extends AtaqueDeAgua{
	
	public Burbuja(){
		this.potencia = 10;
		this.cantidad = 15;
		this.nombre = "Burbuja";
	}

}
