package ataque;

public class CanionDeAgua extends AtaqueDeAgua {

	public CanionDeAgua(){
		this.potencia = 20;
		this.cantidad = 8;
		this.nombre = "Canion de agua";
	}
}

