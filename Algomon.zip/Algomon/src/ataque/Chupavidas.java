package ataque;

public class Chupavidas extends AtaqueDeHierba {
	
	public Chupavidas(){
		this.potencia = 15;
		this.cantidad = 8;
		this.porcentajeDeDrenado = 30;
		this.nombre = "Chupavidas";
	}
}