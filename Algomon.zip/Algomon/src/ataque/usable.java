package ataque;

public interface usable {

}
